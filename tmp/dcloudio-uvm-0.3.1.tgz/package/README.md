# uni-app version manager

## example

```
npx @dcloudio/uvm
```

```
npx @dcloudio/uvm alpha
```

```
npx @dcloudio/uvm 3.2.0
```

```
npx @dcloudio/uvm 3.2.12.20211029
```

```
npx @dcloudio/uvm 3.2.0-alpha
```

```
npx @dcloudio/uvm 3.2.14.20211112-alpha
```
